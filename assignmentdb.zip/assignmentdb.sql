-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2024 at 06:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assignmentdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `studenttb`
--

CREATE TABLE `studenttb` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `department` varchar(3) DEFAULT NULL,
  `cgpa` float DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `credits_completed` int(11) DEFAULT NULL,
  `current_trimester` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studenttb`
--

INSERT INTO `studenttb` (`id`, `name`, `department`, `cgpa`, `date_of_birth`, `credits_completed`, `current_trimester`) VALUES
(1, 'Mahmoud Hussain', 'CSE', 3.8, '2001-12-09', 120, 8),
(2, 'Samiul', 'CSE', 3.7, '2001-01-15', 110, 7),
(3, 'Maruf', 'EEE', 3.5, '2000-06-20', 120, 8),
(4, 'Iftekar', 'BBA', 3.8, '2001-03-12', 130, 9),
(5, 'Saad', 'CE', 3.6, '2002-08-18', 100, 6),
(6, 'Somuddro', 'CSE', 3.4, '1999-12-01', 115, 7),
(7, 'Tahmid', 'EEE', 3.2, '2001-05-24', 105, 6),
(8, 'Taki', 'BBA', 3.7, '2000-09-19', 90, 5),
(9, 'Meem', 'CSE', 3.9, '2001-02-28', 125, 8),
(10, 'Abdullah', 'CE', 3.8, '2000-07-15', 100, 7),
(11, 'Kausar', 'ME', 3.5, '2001-10-05', 118, 7),
(12, 'Mustafizur', 'CSE', 3.6, '2002-11-23', 92, 5),
(13, 'Abu Bakkar', 'EEE', 3.7, '2000-04-08', 115, 8),
(14, 'Kulsum', 'CE', 3.4, '2001-06-10', 105, 6),
(15, 'Maher', 'CSE', 3.8, '1999-03-17', 130, 9),
(16, 'Soleman', 'BBA', 3.9, '2001-07-21', 95, 5),
(17, 'Azizul', 'ME', 3.3, '2000-01-12', 108, 6),
(18, 'Afiza', 'CSE', 3.7, '2002-02-05', 122, 8),
(19, 'Abrar', 'EEE', 3.6, '1999-05-25', 135, 9),
(20, 'Asif', 'CSE', 3.5, '2000-11-13', 112, 7),
(21, 'Sadar', 'CE', 3.2, '2001-08-19', 92, 5),
(22, 'Faheem', 'EEE', 3.4, '2001-09-29', 120, 8),
(23, 'borsha', 'CSE', 2.4, '2004-12-24', 120, 7),
(24, 'bristy', 'BBA', 3.89, '2001-06-09', 120, 6),
(25, 'ibrahim', 'CSE', 3.9, '1999-10-09', 110, 5),
(26, 'ISHA', 'CSE', 3.98, '2002-12-11', 59, 6);

-- --------------------------------------------------------

--
-- Table structure for table `teachertb`
--

CREATE TABLE `teachertb` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `department` varchar(3) DEFAULT NULL,
  `room_no` int(11) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `total_presence_day` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachertb`
--

INSERT INTO `teachertb` (`id`, `name`, `department`, `room_no`, `dob`, `joining_date`, `total_presence_day`) VALUES
(1, 'Fahim', 'CSE', 935, '1997-08-27', '2016-02-25', 200),
(2, 'Abdus', 'EEE', 101, '1985-01-15', '2010-09-01', 500),
(3, 'Shafiq', 'CSE', 102, '1987-05-10', '2012-08-15', 400),
(4, 'Mamun', 'BBA', 103, '1980-11-22', '2008-03-05', 700),
(5, 'Hafiz', 'CE', 104, '1982-07-18', '2009-07-12', 350),
(6, 'Jamil', 'EEE', 105, '1988-02-20', '2014-11-03', 450),
(7, 'Nazmul', 'ME', 106, '1981-03-09', '2007-12-14', 600),
(8, 'Farid', 'CSE', 107, '1990-04-12', '2016-06-20', 320),
(9, 'Aslam', 'EEE', 108, '1986-08-25', '2013-01-05', 500),
(10, 'Manik', 'BBA', 109, '1983-09-15', '2009-10-21', 700),
(11, 'Anis', 'CSE', 110, '1984-06-10', '2011-02-14', 400),
(12, 'Liton', 'EEE', 111, '1989-12-01', '2015-08-29', 360),
(13, 'Harun', 'ME', 112, '1987-07-07', '2012-03-23', 450),
(14, 'Shahin', 'CSE', 113, '1980-02-18', '2008-05-10', 520),
(15, 'Aminul', 'EEE', 114, '1982-10-30', '2010-09-09', 480),
(16, 'Nurul', 'CE', 115, '1985-03-13', '2011-12-07', 500),
(17, 'Zahir', 'ME', 116, '1990-11-23', '2015-04-18', 370),
(18, 'Karim', 'CSE', 117, '1981-08-08', '2009-01-30', 550),
(19, 'Shuvo', 'BBA', 118, '1988-05-15', '2013-09-17', 410),
(20, 'Jahid', 'CSE', 119, '1986-01-25', '2016-03-11', 340),
(21, 'Azad', 'EEE', 120, '1983-06-14', '2012-12-02', 490),
(22, 'Rashid', 'BBA', 121, '1984-07-25', '2009-04-05', 520),
(23, 'Hasan', 'CE', 122, '1985-12-11', '2011-05-19', 430),
(24, 'Ibrahim', 'ME', 123, '1986-10-30', '2010-08-22', 410),
(25, 'Fazlul', 'CSE', 124, '1987-03-22', '2014-02-17', 470),
(26, 'Ashraf', 'EEE', 125, '1988-05-11', '2016-09-01', 390);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `teachertb`
--
ALTER TABLE `teachertb`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
